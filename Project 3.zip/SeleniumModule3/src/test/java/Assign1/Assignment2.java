package Assign1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.DataProvider;
import org.testng.annotations.Test;

public class Assignment2 {

	WebDriver driver;

	@BeforeTest
	public void initializeDriver() {

		driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@DataProvider(name = "loginData")
	public Object[][] getData() {

		return new Object[][] { { "tryfirst@gmail.com", "123456" }, { "try2nd@gmail.com", "987654" },{ "try3rdt@gmail.com", "123456" },

		};
	}

	@Test(dataProvider = "loginData")
	public void loginTest(String username, String password) {

		driver.get("https://demo.guru99.com/test/login.html");

		WebElement usernameField = driver.findElement(By.id("email"));
		WebElement passwordField = driver.findElement(By.id("passwd"));

		usernameField.sendKeys(username);
		passwordField.sendKeys(password);

		passwordField.submit();

	}

	@AfterTest
	public void closeBrowser() throws InterruptedException {

		Thread.sleep(1000);
		driver.close();
	}
}
