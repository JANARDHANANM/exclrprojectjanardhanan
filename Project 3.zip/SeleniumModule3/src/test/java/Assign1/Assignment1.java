package Assign1;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.testng.annotations.AfterTest;
import org.testng.annotations.BeforeTest;
import org.testng.annotations.Test;

public class Assignment1 {

	WebDriver driver;

	@BeforeTest
	public void initializeDriver() {

		driver = new ChromeDriver();
		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);

	}

	@Test
	public void Assignment1() {

		driver.get("https://demo.guru99.com/test/login.html");

		WebElement usernameField = driver.findElement(By.id("email"));
		WebElement passwordField = driver.findElement(By.id("passwd"));

		usernameField.sendKeys("jana");
		passwordField.sendKeys("1213");

	}

	@AfterTest
	public void closeBrowser() throws InterruptedException {

		Thread.sleep(1000);
		driver.close();
	}

}
