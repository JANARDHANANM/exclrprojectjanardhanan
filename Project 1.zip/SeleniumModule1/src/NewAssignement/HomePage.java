package NewAssignement;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

public class HomePage {

	public static void main(String[] args) throws InterruptedException {

		WebDriver driver = new FirefoxDriver();

		navigateAndVerifyTitle(driver);

		driver.quit();

		driver = new ChromeDriver();

		navigateAndVerifyTitle(driver);

		driver.quit();
	}

	private static void navigateAndVerifyTitle(WebDriver driver) throws InterruptedException {
		
		driver.get("https://www.amazon.in/");
		
		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		System.out.println("Title: " + driver.getTitle());
		
		driver.manage().window().maximize();
		
		String actualTitle = driver.getTitle();
		
		String expectedTitle = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";
		
		Thread.sleep(2000);
		
		if (actualTitle.equalsIgnoreCase(expectedTitle))
			
			System.out.println("Title Matched");
				else
			System.out.println("Title didn't match");
	}
}
