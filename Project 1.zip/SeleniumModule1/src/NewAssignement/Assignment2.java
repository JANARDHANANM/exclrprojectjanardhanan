package NewAssignement;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class Assignment2 {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub
		WebDriver driver = new ChromeDriver();

		driver.get("https://demo.guru99.com/test/radio.html");

		driver.findElement(By.id("vfb-7-1")).click();

		driver.findElement(By.id("vfb-6-1")).click();

		Thread.sleep(1000);

		driver.findElement(By.id("vfb-6-2")).click();

		driver.get("https://demo.guru99.com/test/newtours/register.php");

		Select drpCountry = new Select(driver.findElement(By.xpath("//select[@name='country']")));

		drpCountry.selectByVisibleText("KUWAIT");

		Thread.sleep(3000);

		driver.close();

	}

}
