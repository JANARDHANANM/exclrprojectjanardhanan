package Assignments2;

public class TechnologyPage {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

	public void retrieveAllTechnologies() {
		// TODO Auto-generated method stub
		
	}

}
