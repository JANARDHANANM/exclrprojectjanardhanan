package Assignments2;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class FeaturesPage {
    private WebDriver driver;

    // Constructor
    public FeaturesPage(WebDriver driver) {
        this.driver = driver;
    }

    public String retrieveAllFeatures() {
        return driver.findElement(By.id("features-section")).getText();
    }
}
