package Assignments2;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class TestClass {
	public static void main(String[] args) {
		// Set the path to your ChromeDriver executable

		WebDriver driver = new ChromeDriver();
		driver.get(
				"https://itechnotion.com/what-will-be-the-cost-of-an-app-like-justdial-its-indias-no-1-local-business-directory/");

		// Create an instance of the page
		HomePagenew justDialPage = new HomePagenew(driver);

		// Perform actions using page methods
		System.out.println("All Headers: " + justDialPage.getAllHeaders());

		justDialPage.clickOnProductsAndSelectVDoctor();

		System.out.println("Features Content: " + justDialPage.getFeaturesContent());

		System.out.println("Technology Content: " + justDialPage.getTechnologyContent());

		justDialPage.clickOnGetQuote();

		// Enter data from Excel
		justDialPage.enterDataIntoForm("C:\\Users\\Janardhan\\Downloads\\C7EB6D50.xlsx");

		// Select an interest option
		justDialPage.selectInterestOption("your_interest_option");

		justDialPage.clickOnSubmit();

		// Close the browser
		driver.quit();

	}
}
