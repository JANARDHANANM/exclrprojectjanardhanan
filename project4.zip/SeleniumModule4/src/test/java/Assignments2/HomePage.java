package Assignments2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class HomePage {
	private WebDriver driver;

	// Constructor
	public HomePage(WebDriver driver) {
		this.driver = driver;
	}

	public void clickProducts() {
		driver.findElement(By.linkText("Products")).click();
	}
}
