package Assignments2;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;

public class GetQuotePage {
    private WebDriver driver;

    // Constructor
    public GetQuotePage(WebDriver driver) {
        this.driver = driver;
    }

    public void enterDataFromExcel(String data) {
        // Implement entering data from Excel
        // Example: driver.findElement(By.id("dataInput")).sendKeys(data);
    }

    public void selectInterestOption(String option) {
        // Implement selecting an option
        // Example: driver.findElement(By.id("interestDropdown")).sendKeys(option);
    }

    public void clickSubmit() {
        driver.findElement(By.id("submitButton")).click();
    }
}
