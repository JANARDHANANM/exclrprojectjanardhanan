package Assignments2;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.support.FindBy;
import org.openqa.selenium.support.PageFactory;

public class HomePagenew {
    private final WebDriver driver;

    public HomePagenew(WebDriver driver) {
        this.driver = driver;
        PageFactory.initElements(driver, this);
    }

    // Find elements using @FindBy annotations
    @FindBy(xpath = "//h1")
    private WebElement headers;

    @FindBy(linkText = "Products")
    private WebElement productsLink;

    @FindBy(linkText = "vDoctor")
    private WebElement vDoctorLink;

    @FindBy(linkText = "FEATURES")
    private WebElement featuresLink;

    @FindBy(linkText = "TECHNOLOGY")
    private WebElement technologyLink;

    @FindBy(linkText = "Get Quote")
    private WebElement getQuoteLink;

    @FindBy(xpath = "//your-xpath-for-form-inputs")
    private WebElement formInputs;

    @FindBy(id = "yourInterestDropdown")
    private WebElement interestDropdown;

    @FindBy(id = "submitBtn")
    private WebElement submitButton;

    // Create methods to perform actions

    public String getAllHeaders() {
        return headers.getText();
    }

    public void clickOnProductsAndSelectVDoctor() {
        productsLink.click();
        vDoctorLink.click();
    }

    public String getFeaturesContent() {
        featuresLink.click();
        return featuresLink.getText();
    }

    public String getTechnologyContent() {
        technologyLink.click();
        return technologyLink.getText();
    }

    public void clickOnGetQuote() {
        getQuoteLink.click();
    }

    public void enterDataIntoForm(String data) {
        // Implement logic to enter data into form inputs based on Excel sheet
        formInputs.sendKeys(data);
    }

    public void selectInterestOption(String option) {
        // Implement logic to select an option in the dropdown
        // You may use Select class for dropdowns
        // Example: new Select(interestDropdown).selectByVisibleText(option);
    }

    public void clickOnSubmit() {
        submitButton.click();
    }

	public void clickProducts() {
		// TODO Auto-generated method stub
		
	}
}
