package Assignments2;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;

import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

public class TestScenario {

	public static void main(String[] args) {
		// Setting up Firefox WebDriver
		WebDriver firefoxDriver = new FirefoxDriver();
		// Setting up Opera WebDriver

		WebDriver Driver = new ChromeDriver();

		// Navigate and verify Amazon homepage
		navigateAndVerifyHomePage(firefoxDriver, "https://www.amazon.com", "Amazon");
		// Navigate and verify Facebook homepage
		// navigateAndVerifyHomePage(firefoxDriver, "https://www.facebook.com",
		// "Facebook");

		// Verify page title
		verifyPageTitle(firefoxDriver, "Amazon");
		// verifyPageTitle(firefoxDriver, "Facebook");

		// Navigate using browser navigation
		navigateAndVerifyHomePage(firefoxDriver, "https://www.google.com", "Google");
		navigateAndVerifyHomePage(firefoxDriver, "https://www.amazon.com", "Amazon");

		// Close all WebDriver instances
		firefoxDriver.quit();

	}

	public static void navigateAndVerifyHomePage(WebDriver driver, String url, String siteName) {
		driver.get(url);
		String pageTitle = driver.getTitle();
		System.out.println("Verifying " + siteName + " homepage...");
		if (pageTitle.contains(siteName)) {
			System.out.println(siteName + " homepage verified successfully.");
		} else {
			System.out.println("Failed to verify " + siteName + " homepage.");
		}
	}

	public static void verifyPageTitle(WebDriver driver, String siteName) {
		String pageTitle = driver.getTitle();
		System.out.println("Verifying " + siteName + " page title...");
		if (pageTitle.contains(siteName)) {
			System.out.println(siteName + " page title verified successfully.");
		} else {
			System.out.println("Failed to verify " + siteName + " page title.");
		}
	}
}
