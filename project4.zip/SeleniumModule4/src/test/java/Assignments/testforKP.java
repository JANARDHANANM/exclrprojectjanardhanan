package Assignments;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class testforKP {

	public static void main(String[] args) throws IOException, InterruptedException {

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		driver.get("https://mountcarmelcollege.iolite.co.in/KnowledgePro/Login.do");

		driver.findElement(By.name("userName")).sendKeys("jana");

		driver.findElement(By.name("password")).sendKeys("8148899847");

		driver.findElement(By.xpath("//input[@value='Sign In']")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@onclick='appendMethodOnBrowserClose(),openClose()']")).click();

		Thread.sleep(2000);

		driver.findElement(By.xpath("//input[@name='search']")).sendKeys("update");

		Thread.sleep(2000);

		driver.findElement(By.xpath("//a[@href='updateProcess.do?method=initUpdateProcess&menuName=Update Process']")).click();
		
		
		
		for(int i=check_0;i<check_4;i++);
		
		{

		Select dropYear = new Select(driver.findElement(By.name("batchYear")));

		dropYear.selectByVisibleText("2021");

		Select Process = new Select(driver.findElement(By.name("process")));

		Process.selectByVisibleText("Calculate Overall regular Exam marks");

		Thread.sleep(2000);

		Select Exam = new Select(driver.findElement(By.id("examId")));

		Exam.selectByVisibleText("B.ED ESE ODD NOV 2023");

		driver.findElement(By.name("Submit2")).click();

		WebElement Year = driver.findElement(By.id("check_0"));
		
		Year(i);

		Year.click();

		}
		

		/**
		 * FileInputStream file = new
		 * FileInputStream("C:\\Users\\Janardhan\\Downloads\\.xlsx");
		 * 
		 * XSSFWorkbook workbook = new XSSFWorkbook(file);
		 * 
		 * XSSFSheet sheet = workbook.getSheet("Sheet1");
		 * 
		 * int row = sheet.getLastRowNum();
		 * 
		 * for (int i = 1; i <= row; i++)
		 * 
		 * {
		 * 
		 * XSSFRow curentSheet = sheet.getRow(i);
		 * 
		 * String emailid = curentSheet.getCell(0).getStringCellValue();
		 * 
		 * driver.findElement(By.name("registerNo")).sendKeys(emailid);
		 * 
		 * driver.findElement(By.xpath("//input[@name='submit']")).click();
		 * 
		 * Thread.sleep(3000);
		 * 
		 * driver.findElement(By.xpath("//input[@onclick='appendMethodOnBrowserClose(),cancelPromotion()']")).click();
		 * 
		 * Thread.sleep(3000);
		 * 
		 * driver.findElement(By.name("registerNo")).sendKeys(Keys.chord(Keys.CONTROL,
		 * "a", Keys.DELETE));
		 * 
		 * }
		 * 
		 * workbook.close();
		 **/
	}
}
