package Assignments;

import java.io.FileInputStream;
import java.io.IOException;
import java.time.Duration;

import org.apache.poi.xssf.usermodel.XSSFRow;
import org.apache.poi.xssf.usermodel.XSSFSheet;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.openqa.selenium.By;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

public class Assignment1 {

	public static void main(String[] args) throws IOException, InterruptedException {

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get("https://demo.guru99.com/V4/");

		driver.manage().timeouts().implicitlyWait(Duration.ofSeconds(20));

		FileInputStream file = new FileInputStream("C:\\Users\\Janardhan\\Downloads\\C7EB6D50.xlsx");

		XSSFWorkbook workbook = new XSSFWorkbook(file);

		XSSFSheet sheet = workbook.getSheet("Sheet1");

		int row = sheet.getLastRowNum();

		for (int i = 1; i <= row; i++)

		{

			XSSFRow curentSheet = sheet.getRow(i);

			String emailid = curentSheet.getCell(0).getStringCellValue();

			String password = curentSheet.getCell(1).getStringCellValue();

			driver.findElement(By.xpath("//input[@name='uid']")).sendKeys(emailid);

			driver.findElement(By.xpath("//input[@name='password']")).sendKeys(password);

			Thread.sleep(3000);

			driver.findElement(By.xpath("//input[@name='uid']")).sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));

			driver.findElement(By.xpath("//input[@name='password']")).sendKeys(Keys.chord(Keys.CONTROL, "a", Keys.DELETE));

		}

		driver.close();

	}

}
