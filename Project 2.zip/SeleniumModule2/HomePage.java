package NewAssignement;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.firefox.FirefoxDriver;
import org.openqa.selenium.ie.InternetExplorerDriver;
import org.openqa.selenium.safari.SafariDriver;

public class HomePage {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		 WebDriver driver = new ChromeDriver();

		// WebDriver driver = new FirefoxDriver();
		// WebDriver driver = new InternetExplorerDriver();

		//WebDriver driver = new SafariDriver();



		driver.manage().timeouts().implicitlyWait(10, TimeUnit.SECONDS);
		
		driver.get("https://www.amazon.in/");

		System.out.println(driver.getTitle());

		driver.manage().window().maximize();

	String actualTitle = driver.getTitle();

		String expectTiltleString = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";

		String expectedTitle = "Online Shopping site in India: Shop Online for Mobiles, Books, Watches, Shoes and More - Amazon.in";

		Thread.sleep(8000);

		if (actualTitle.equalsIgnoreCase(expectedTitle))
			System.out.println("Title Matched");
		else
			System.out.println("Title didn't match");

		driver.navigate().to("https://www.bangaloretourstravelss.com/");

		//driver.navigate().back();
		
		
		
		//driver.findElement(By.xpath("//div[@class='elementor-element elementor-element-1744343 elementor-icon-list--layout-inline elementor-align-right elementor-mobile-align-center elementor-list-item-link-full_width elementor-widget elementor-widget-icon-list']//span[@class='elementor-icon-list-text'][normalize-space()='Logins']")).click();   

	}

}
