package Assignment1;

import java.util.List;

import javax.xml.xpath.XPath;

import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.support.ui.Select;

public class WebTable {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver = new ChromeDriver();

		driver.get("https://demo.guru99.com/test/web-table-element.php");

		List<WebElement> FetchTable = driver.findElements(By.xpath("//table[@class='dataTable']/tbody/tr/td[1]"));

		System.out.println(FetchTable.size());

		for (WebElement companyName : FetchTable)

		{

			String value = companyName.getText();

			System.out.println(value);
		}

		driver.navigate().forward();
		
		Thread.sleep(3000);

		driver.get("https://demo.guru99.com/test/login.html");

		driver.findElement(By.id("email")).sendKeys("jana@gmail.com");

		driver.findElement(By.id("passwd")).sendKeys("123456789");

		driver.findElement(By.id("SubmitLogin")).click();

		 driver.findElement(By.xpath("//div[@class='error-copy']/h3"));
		
		

	}

}
