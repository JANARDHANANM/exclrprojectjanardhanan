package Assignment2;

import java.util.List;
import java.util.concurrent.TimeUnit;

import org.openqa.selenium.By;
import org.openqa.selenium.By.ByXPath;
import org.openqa.selenium.Keys;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import org.openqa.selenium.chrome.ChromeDriver;

public class Windows {

	public static void main(String[] args) throws InterruptedException {
		// TODO Auto-generated method stub

		WebDriver driver = new ChromeDriver();

		driver.manage().window().maximize();

		driver.get("http://demo.guru99.com/popup.php");

		driver.findElement(By.xpath("//*[text()='Click Here']")).click();

		Thread.sleep(6000);
			
		//driver.switchTo().frame("__ccpaLocator");
		
		 driver.findElement(By.xpath("//input[@name='emailid']")).sendKeys("example@example.com");

	}

}
